package com.example.receitas.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.receitas.R
import com.example.receitas.entity.Receitas
import kotlinx.android.synthetic.main.item_lista.view.*


class ReceitasRecyclerViewAdapter(): RecyclerView.Adapter<ReceitasRecyclerViewAdapter.ViewHolder>() {

    var onItemClickListener: ((Receitas) -> Unit)? = null

    //cria uma lista vazia
    private var receitasList = emptyList<Receitas>()


    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lista, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = receitasList.count()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val receitas = receitasList[position]
        holder.txt_receita.text = receitas.receita
        holder.txt_rendimento.text = receitas.rende.toString()
    }

    fun setReceitasList(receitas:List<Receitas>){
        this.receitasList = receitas
        notifyDataSetChanged()
    }

    inner class ViewHolder (view: View): RecyclerView.ViewHolder(view){

        init {
            itemView.setOnClickListener{
                onItemClickListener?.invoke(receitasList[adapterPosition])
            }
        }

        val txt_receita: TextView = view.txtReceita
        val txt_rendimento: TextView = view.txtRende

    }

}