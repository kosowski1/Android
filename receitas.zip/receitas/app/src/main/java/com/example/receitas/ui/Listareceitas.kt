package com.example.receitas.ui

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.receitas.R
import com.example.receitas.adapter.ReceitasRecyclerViewAdapter
import com.example.receitas.entity.Receitas
import com.example.receitas.viewmodel.ReceitasViewModel
import kotlinx.android.synthetic.main.activity_listareceitas.*
import java.lang.Exception

class Listareceitas : AppCompatActivity() {
    private lateinit var receitasviewModel: ReceitasViewModel

    lateinit var notificationManager: NotificationManagerCompat

    val REQUEST_CODE = 12
    val REQUEST_CODE_UPDATE = 13
    val CHANNEL_ID = "com.example.receitas.ui.CHANNEL_ID"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listareceitas)

        notificationManager = NotificationManagerCompat.from(this)

        val recyclerView_: RecyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        montaLista(recyclerView_)

        btn_add.setOnClickListener {
            val intent = Intent(
            this,
                MainActivity::class.java
            )
            startActivityForResult(intent, REQUEST_CODE)
        }
    }
    private fun montaLista(recyclerView_: RecyclerView) {
        recyclerView_.setHasFixedSize(true)

        // responsável por medir e posicionar as visualizações dos itens
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)

        recyclerView_.layoutManager = layoutManager

        val adapter = ReceitasRecyclerViewAdapter()

        adapter.onItemClickListener = { it ->
            val intent = Intent(this@Listareceitas,
                MainActivity::class.java)
            intent.putExtra(MainActivity.EXTRA_REPLY, it)
            startActivityForResult(intent, REQUEST_CODE_UPDATE)
        }

        recyclerView_.adapter = adapter

       receitasviewModel = ViewModelProviders.of(this).get(ReceitasViewModel::class.java)

        // recebe todos os dados do banco e atualiza no adapter
        receitasviewModel.allReceitas.observe(this, Observer { bikes -> bikes?.let { adapter.setReceitasList(it) } })

    }

override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
        data?.let { resultado ->
            try {
                val receitas = resultado.extras?.get(MainActivity.EXTRA_REPLY) as Receitas
                receitas.let {
                    receitasviewModel.insert(receitas)
                }
            } catch (e: Exception) {
                Log.d("TAG:", e.message)
            }
        }
    } else if (requestCode == REQUEST_CODE_UPDATE && resultCode == Activity.RESULT_OK) {
        data?.let { resultado ->
            try {
                var receitas: Receitas? = resultado.extras?.get(MainActivity.EXTRA_REPLY) as? Receitas
                if (receitas == null) {
                    receitas = resultado.extras?.get(MainActivity.EXTRA_DELETE) as? Receitas
                    receitas.let {
                        showNotification("EXCLUSÃO REALIZADA", it!!.receita)

                        receitasviewModel.delete(it)
                    }
                } else {
                    receitas.let { receitasviewModel.update(receitas) }
                }
            }catch (e:Exception){
            Log.d("TAG: ", e.message)
            }
        }
    }
}
    private fun showNotification(titulo: String, conteudo: String) {
        val notification =
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_delete)
                .setContentTitle(titulo)
                .setContentText(conteudo)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        notificationManager.notify(1, notification)
    }
}
