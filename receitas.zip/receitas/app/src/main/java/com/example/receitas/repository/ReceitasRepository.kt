package com.example.receitas.repository

import androidx.lifecycle.LiveData
import com.example.receitas.db.ReceitasDAO
import com.example.receitas.entity.Receitas

class ReceitasRepository(private val receitasDAO: ReceitasDAO) {

val allreceitas:LiveData<List<Receitas>> =receitasDAO.getAll()

    fun insert(receitas: Receitas){
    receitasDAO.insert(receitas)
    }

    fun update(receitas: Receitas){
        receitasDAO.update(receitas)
    }

    fun delete(receitas: Receitas){
        receitasDAO.delete(receitas)
    }

}