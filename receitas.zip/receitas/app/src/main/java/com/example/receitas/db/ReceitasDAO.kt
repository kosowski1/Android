package com.example.receitas.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.receitas.entity.Receitas


@Dao
interface ReceitasDAO {

@Insert
fun insert (receitas: Receitas)

@Update
fun update (receitas: Receitas)

@Delete
fun delete(receitas: Receitas)

    @Query("SELECT * FROM receitas_table ORDER BY receita ASC")
    fun getAll(): LiveData<List<Receitas>>

    @Query("SELECT * FROM receitas_table WHERE id = :id_")
    fun getReceitas(id_ : Long): LiveData<Receitas>

    @Query("DELETE FROM receitas_table")
    fun deleteAll()

}