package com.example.receitas.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.receitas.db.ReceitasDataBase
import com.example.receitas.entity.Receitas
import com.example.receitas.repository.ReceitasRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext


class ReceitasViewModel (application: Application): AndroidViewModel(application) {

    private val parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)

    private val repository: ReceitasRepository
    val allReceitas: LiveData<List<Receitas>>

init{
val receitasDAO = ReceitasDataBase.getDataBase(application).receitasDAO()
    repository = ReceitasRepository(receitasDAO)
    allReceitas = repository.allreceitas
}
    fun insert(receitas:Receitas) = scope.launch (Dispatchers.IO){
repository.insert(receitas)
    }
    fun update(receitas: Receitas) = scope.launch(Dispatchers.IO) {
        repository.update(receitas)
    }

    fun delete(receitas: Receitas) = scope.launch(Dispatchers.IO) {
        repository.delete(receitas)
    }

}