package com.example.receitas.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull
import java.io.Serializable

@Entity(tableName = "receitas_table")
class Receitas (
    @NotNull
    @ColumnInfo(name="receita")
    var receita: String="",

    @ColumnInfo(name= "duracao")
    var duracao: Int=0,

    @ColumnInfo(name = "rende")
    var rende: Int=0,

    @ColumnInfo(name="igrediente1")
    var igrediente1: String="",

    @ColumnInfo(name="igrediente2")
    var igrediente2: String="",

    @ColumnInfo(name="igrediente3")
    var igrediente3: String="",

    @ColumnInfo(name="igrediente4")
    var igrediente4: String="",

    @ColumnInfo(name="igrediente5")
    var igrediente5: String="",

    @ColumnInfo(name="preparo")
    var preparo: String=""
):Serializable{

    @PrimaryKey(autoGenerate = true)
    var id: Long = 0

}