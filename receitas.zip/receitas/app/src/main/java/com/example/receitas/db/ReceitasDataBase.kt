package com.example.receitas.db

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room
import com.example.receitas.entity.Receitas



@Database(entities = [Receitas::class], version = 1)
abstract class ReceitasDataBase :RoomDatabase() {

    abstract fun receitasDAO(): ReceitasDAO

    companion object{
    private var INSTANCE:ReceitasDataBase? = null

    fun getDataBase(context: Context):ReceitasDataBase{
        return INSTANCE?: synchronized(this){
            val instance = Room.databaseBuilder(
                context.applicationContext,
                ReceitasDataBase::class.java,
            "receitas_db"
        )
                .fallbackToDestructiveMigration()
                .build()
            INSTANCE = instance
            return instance
            }
        }
    }
    }