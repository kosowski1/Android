package com.example.receitas.ui

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.example.receitas.R
import com.example.receitas.entity.Receitas
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception


class MainActivity : AppCompatActivity() {

    lateinit var receitas: Receitas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val intent = intent

        try{
            receitas = intent.extras?.get(EXTRA_REPLY) as Receitas
            receitas.let {
            edtReceitas.setText(it.receita)
            edtDuracao.setText(it.duracao.toString())
            edtRende.setText(it.rende.toString())
            edtIgd1.setText(it.igrediente1)
            edtIgd2.setText(it.igrediente2)
            edtIgd3.setText(it.igrediente3)
            edtIgd4.setText(it.igrediente4)
            edtIgd5.setText(it.igrediente5)
            edtPreparo.setText(it.preparo)
        }
        }catch (e:Exception){
        Log.e("TAG: ", e.message)
        }
    }
    private fun populaObjeto() {

        if (edtReceitas.text.isNotEmpty()) {
            receitas.receita = edtReceitas.text.toString()
        }
        if (edtDuracao.text.isNotEmpty()) {
            receitas.duracao = edtDuracao.text.toString().toInt()
        }
        if (edtRende.text.isNotEmpty()) {
            receitas.rende = edtRende.text.toString().toInt()
        }
        if (edtIgd1.text.isNotEmpty()) {
            receitas.igrediente1 = edtIgd1.text.toString()
        }
        if (edtIgd2.text.isNotEmpty()) {
            receitas.igrediente2 = edtIgd2.text.toString()
        }
        if (edtIgd3.text.isNotEmpty()) {
            receitas.igrediente3 = edtIgd3.text.toString()
        }
        if (edtIgd4.text.isNotEmpty()) {
            receitas.igrediente4 = edtIgd4.text.toString()
        }
        if (edtIgd5.text.isNotEmpty()) {
            receitas.igrediente5 = edtIgd5.text.toString()
        }
        if (edtPreparo.text.isNotEmpty()) {
            receitas.preparo = edtPreparo.text.toString()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_projeto, menu)

        try {
            receitas.let {
                val menuItem = menu?.findItem(R.id.menu_excluir)
                menuItem?.isVisible = true
            }
        } catch (e: Exception){
            Log.e("TAG: ", "Novo item " + e.message)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        return if(item?.itemId == android.R.id.home){
            finish()
            true
        } else if (item?.itemId == R.id.menu_save){
            val retornaIntent = Intent()

            if(edtReceitas.text.isNullOrEmpty()){
                Toast.makeText(this, "A receita não pode ser vazia", Toast.LENGTH_LONG).show()

            } else if(edtRende.text.isNullOrEmpty()){
                Toast.makeText(this, "Rendimento não pode ser vazio", Toast.LENGTH_LONG).show()

            } else if (edtDuracao.text.isNullOrEmpty()){
                Toast.makeText(this, "Duração não pode estar vazio", Toast.LENGTH_LONG).show()

            } else if(edtPreparo.text.isNullOrEmpty()){
                Toast.makeText(this, "Preparo não pode estar vazio", Toast.LENGTH_LONG).show()

            } else if (edtIgd1.text.isNullOrEmpty()){
                Toast.makeText(this, "Minimo 1 Igrediente", Toast.LENGTH_LONG).show()

            } else {
                try {
                    if ((::receitas.isInitialized) && receitas.id > 0){
                        populaObjeto()
                    } else {
                        receitas = Receitas()
                        populaObjeto()
                    }
                    retornaIntent.putExtra(EXTRA_REPLY, receitas)
                } catch (e: Exception){
                    setResult(Activity.RESULT_CANCELED, retornaIntent)
                }
                setResult(Activity.RESULT_OK, retornaIntent)
                finish()
            }
            true

        } else if(item?.itemId == R.id.menu_excluir){
            if((::receitas.isInitialized) && receitas.id > 0){
                val replyIntent = Intent()
                replyIntent.putExtra(EXTRA_DELETE, receitas)
                setResult(Activity.RESULT_OK, replyIntent)
                finish()
            }
            true
        } else {
            return super.onOptionsItemSelected(item)
        }
    }
       companion object{
            const val EXTRA_REPLY = "com.example.receitas.ui.REPLY"
            const val EXTRA_DELETE = "com.example.receitas.ui.DELETE"
        }
    }

